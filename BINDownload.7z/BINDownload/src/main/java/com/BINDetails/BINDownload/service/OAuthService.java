package com.BINDetails.BINDownload.service;

import com.BINDetails.BINDownload.config.OAuthConfig;
import com.BINDetails.BINDownload.exception.BinServiceException;
import com.BINDetails.BINDownload.feign.OAuthFeignClient;
import com.BINDetails.BINDownload.model.OAuthDetailsAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Base64;
import java.util.Map;

@Service
public class OAuthService {

    @Autowired
    private OAuthConfig oAuthConfig;

    @Autowired
    private OAuthFeignClient oAuthFeignClient;

     private OAuthDetailsAPI oAuthDetailsAPI;


    /**
     * Below method use to fetched Bearer Token from EFTPOS API
     * @return Bearer token
     */
     public String getAccessToken(){
        try{
            String auth = oAuthConfig.getClientId() + ":" + oAuthConfig.getClientSecret();
            String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes());
            String authorizationHeader = "Basic" + encodedAuth;
            oAuthDetailsAPI = oAuthFeignClient.getToken(authorizationHeader,"client_credentials",oAuthConfig.getClientId());
          }catch (Exception e){



        }
        return oAuthDetailsAPI.getAccess_Token();
    }
}
