package com.BINDetails.BINDownload.service;

import com.BINDetails.BINDownload.config.OAuthConfig;
import com.BINDetails.BINDownload.exception.BinServiceException;
import com.BINDetails.BINDownload.exception.ForbiddenException;
import com.BINDetails.BINDownload.exception.UnauthorizedException;
import com.BINDetails.BINDownload.feign.BinFeignClient;
import com.BINDetails.BINDownload.feign.OAuthFeignClient;
import com.BINDetails.BINDownload.model.BinAPIResponse;
import com.BINDetails.BINDownload.model.OAuthDetailsAPI;
import feign.FeignException;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Base64;
import java.util.List;

public class ApolloBinServiceImpl implements ApolloBinService {
    @Autowired
    private BinFeignClient binFeignClient;

    @Autowired
    private OAuthConfig oAuthConfig;

    @Autowired
    private OAuthFeignClient oAuthFeignClient;

    @Autowired
    private OAuthDetailsAPI oAuthDetailsAPI;



        public List<BinAPIResponse> getBinDetails() throws ForbiddenException, BinServiceException {
            try {
                
               String bearerToken= getAccessToken();

                BinAPIResponse  binAPIResponse =  binFeignClient.getBinDetails(bearerToken);

               

            } catch (FeignException e) {
                if (e.status() == 401) {
                    throw new UnauthorizedException("Unauthorized: Invalid Credentials");
                }
                if(e.status() == 403){
                    throw new ForbiddenException("Forbidden: Access denied.");
                }
                throw new BinServiceException("FeignException occurred while getting Bin Details ", e);

            }
            return List.of();
        }

    private String getAccessToken() {
       // String auth = oAuthConfig.getClientId() + ":" + oAuthConfig.getClientSecret();
        String auth = "UONgGxAF7MVGL3GRcuXFY3kmcXkJpzjV" + ":" + "GAMIqSeYkF2Xa5LK";
        String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes());
        String authorizationHeader = "Basic" + encodedAuth;
        oAuthDetailsAPI = oAuthFeignClient.getToken(authorizationHeader,"client_credentials",oAuthConfig.getClientId());
        return oAuthDetailsAPI.getAccess_Token();
    }
}
