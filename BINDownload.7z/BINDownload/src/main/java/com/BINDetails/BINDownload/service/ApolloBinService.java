package com.BINDetails.BINDownload.service;

import com.BINDetails.BINDownload.exception.BinServiceException;
import com.BINDetails.BINDownload.exception.ForbiddenException;
import com.BINDetails.BINDownload.model.BinAPIResponse;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ApolloBinService {

    /**
     * getting bin details from fiserv
     * @return BinResponse
     */

    public List<BinAPIResponse> getBinDetails() throws ForbiddenException, BinServiceException;
}
