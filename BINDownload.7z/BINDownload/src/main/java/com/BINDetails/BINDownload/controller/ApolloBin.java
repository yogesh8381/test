//package com.BINDetails.BINDownload.controller;
//import io.swagger.model.ErrorInformation;
//import io.swagger.model.InlineResponse200;
//import io.swagger.model.InlineResponse2001;
//import io.swagger.v3.oas.annotations.Operation;
//import io.swagger.v3.oas.annotations.Parameter;
//import io.swagger.v3.oas.annotations.enums.ParameterIn;
//import io.swagger.v3.oas.annotations.responses.ApiResponses;
//import io.swagger.v3.oas.annotations.responses.ApiResponse;
//import io.swagger.v3.oas.annotations.media.ArraySchema;
//import io.swagger.v3.oas.annotations.media.Content;
//import io.swagger.v3.oas.annotations.media.Schema;
//import io.swagger.v3.oas.annotations.security.SecurityRequirement;
//import org.springframework.http.ResponseEntity;
//import org.springframework.validation.annotation.Validated;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestHeader;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RequestPart;
//import org.springframework.web.multipart.MultipartFile;
//import org.springframework.web.bind.annotation.CookieValue;
//
//import java.util.List;
//
//public interface ApolloBin {
//    @ApiResponses(value = {
//            @ApiResponse(responseCode = "200", description = "Successful: an array of one or more BIN items is returned.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = InlineResponse2001.class))),
//
//            @ApiResponse(responseCode = "400", description = "Bad request: the request could not be understood by the server due to malformed syntax. The client should not repeat the request without modifications. (NOT USED - INTENDED FOR FUTURE)", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorInformation.class))),
//
//            @ApiResponse(responseCode = "401", description = "Unauthorized: the request requires user authentication.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorInformation.class))),
//
//            @ApiResponse(responseCode = "402", description = "Unauthorized: the request requires user authentication.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorInformation.class))),
//
//            @ApiResponse(responseCode = "403", description = "Forbidden: the server understood the request, but is refusing to fulfill it. Authorization will not help and the request should not be repeated. (NOT USED - INTENDED FOR FUTURE)", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorInformation.class))),
//
//            @ApiResponse(responseCode = "429", description = "Too many requests: the user has sent too many requests in a given amount of time. (NOT USED - INTENDED FOR FUTURE)", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorInformation.class))),
//
//            @ApiResponse(responseCode = "500", description = "Internal server error: the server encountered an unexpected condition which prevented it from fulfilling the request. (NOT USED - INTENDED FOR FUTURE)", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorInformation.class))) })
//    @RequestMapping(value = "/bins",
//            produces = { "application/json" },
//            method = RequestMethod.GET)
//    ResponseEntity<InlineResponse2001> getBins(@Parameter(in = ParameterIn.HEADER, description = "UUID to be used across end-to-end API Calls, if not supplied by the caller of the API it will be added at API Gateway and included in the response" ,schema=@Schema()) @RequestHeader(value="x-correlation-id", required=false) String xCorrelationId
//            , @DecimalMin("1")@Parameter(in = ParameterIn.QUERY, description = "The maximum number of items to return." ,schema=@Schema()) @Valid @RequestParam(value = "limit", required = false) String limit
//            , @Size(min=6,max=8) @Parameter(in = ParameterIn.QUERY, description = "The 6-8 digit string identifying a BIN. The first item returned will be the one which follows the identified BIN in the collection. (Typically, the identified BIN would be that of the last item returned in a previous response.)" ,schema=@Schema()) @Valid @RequestParam(value = "after", required = false) String after
//            , @Parameter(in = ParameterIn.QUERY, description = "A list of transaction types which are supported digitally for accounts in this BIN by the eftpos Issuer.  <b>Note: This tag and value is not applicable for Mobile payment and must be ignored.It can be identified by binProductType=token </b>" ,schema=@Schema(allowableValues={ "deposit", "purchase", "refund", "withdrawal", "none" }
//    )) @Valid @RequestParam(value = "eftposDigitalTransactionTypesAllowed", required = false) List<String> eftposDigitalTransactionTypesAllowed
//    );
//}
