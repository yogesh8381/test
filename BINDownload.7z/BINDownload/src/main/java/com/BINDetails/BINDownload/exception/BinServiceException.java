package com.BINDetails.BINDownload.exception;

import feign.FeignException;

public class BinServiceException extends Exception {
    public BinServiceException(String message) {
        super(message);
    }

    public BinServiceException(String message, FeignException e) {
    }
}
