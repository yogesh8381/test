package com.BINDetails.BINDownload.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class BinInformation {

    private String bin;
    private String binProductType;
    private String binProductSubtype;
    private  String eftposIssuerName;
    private  String panLength;
    private String isTokenizable;

    private List<String> eftposDigitalTransactionTypesAllowed;

    public BinInformation(String bin, String binProductType, String binProductSubtype, String eftposIssuerName, String panLength, String isTokenizable, List<String> eftposDigitalTransactionTypesAllowed) {
        this.bin = bin;
        this.binProductType = binProductType;
        this.binProductSubtype = binProductSubtype;
        this.eftposIssuerName = eftposIssuerName;
        this.panLength = panLength;
        this.isTokenizable = isTokenizable;
        this.eftposDigitalTransactionTypesAllowed = eftposDigitalTransactionTypesAllowed;
    }
}
