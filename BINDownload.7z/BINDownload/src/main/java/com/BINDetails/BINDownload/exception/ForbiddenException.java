package com.BINDetails.BINDownload.exception;

public class ForbiddenException extends Exception {
    public ForbiddenException(String message) {
        super(message);
    }
}
