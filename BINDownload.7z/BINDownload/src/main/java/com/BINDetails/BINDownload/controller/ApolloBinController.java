package com.BINDetails.BINDownload.controller;

import com.BINDetails.BINDownload.exception.BinServiceException;
import com.BINDetails.BINDownload.exception.ForbiddenException;
import com.BINDetails.BINDownload.model.BinAPIResponse;
import com.BINDetails.BINDownload.service.ApolloBinService;
import feign.FeignException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ApolloBinController {
    private  ApolloBinService apolloBinService;

    private static final Logger logger = LoggerFactory.getLogger(ApolloBinController.class);

    @GetMapping("/Bins")
    public ResponseEntity<List<BinAPIResponse>> getBinDetails() throws BinServiceException {
        try {
            logger.trace("ApolloBinController.getBinDetails");
            List<BinAPIResponse> binResponseList = apolloBinService.getBinDetails();
            return ResponseEntity.ok(binResponseList);
        }catch (FeignException | ForbiddenException e){
            throw new BinServiceException("Exception occurred while getting UserGroups");

        }
    }
}
