package com.BINDetails.BINDownload.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter @Setter
public class BinAPIResponse {
    private List<BinInformation> binInformations;


    public List<BinInformation> getBinInformations() {
        return binInformations;
    }

    public void setBinInformations(List<BinInformation> binInformations) {
        this.binInformations = binInformations;
    }

}
