package com.BINDetails.BINDownload.feign;
import com.BINDetails.BINDownload.model.BinAPIResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "EFTPOSBinDetails", url = "https://sandbox.api.eftpos.io/bin/v1")
public interface BinFeignClient {

    @GetMapping(value = "/bins",
            produces = { "application/json" })
    BinAPIResponse getBinDetails(@RequestParam("Authorization") String bearerToken);

}
