package com.BINDetails.BINDownload.feign;

import com.BINDetails.BINDownload.model.OAuthDetailsAPI;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

@FeignClient(name = "oauthClient", url="https://sandbox.api.eftpos.io")
public interface OAuthFeignClient {
    @PostMapping(value= "/oauth/v1/token", consumes = "application/x-www-form-urlencoded")
    OAuthDetailsAPI getToken(
            @RequestHeader("Authorization") String authorization,
            @RequestParam("client_id") String clientId,
            @RequestParam("grant_type") String grantType
    );
}
