package com.BINDetails.BINDownload.exception;

import feign.Response;
import feign.codec.ErrorDecoder;

public class FeignErrorDecoder implements ErrorDecoder {
    @Override
    public Exception decode(String s, Response response) {
        int status = response.status();
        switch (status){
            case 401:
                return new UnauthorizedException("Unauthorized: Invalid Credentials");
            case 403:
                return new ForbiddenException("Forbidden: Access denied.");
            default:
                return  new BinServiceException("External service error:" + status);
        }

    }
}
