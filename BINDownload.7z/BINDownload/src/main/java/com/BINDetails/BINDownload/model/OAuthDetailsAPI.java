package com.BINDetails.BINDownload.model;


public class OAuthDetailsAPI {

     private String client_Id;
     private String access_Token;
     private String expires_In;
     private String scopes;
     private String token_type;

     public String getClient_Id() {
          return client_Id;
     }

     public void setClient_Id(String client_Id) {
          this.client_Id = client_Id;
     }

     public String getAccess_Token() {
          return access_Token;
     }

     public void setAccess_Token(String access_Token) {
          this.access_Token = access_Token;
     }

     public String getExpires_In() {
          return expires_In;
     }

     public void setExpires_In(String expires_In) {
          this.expires_In = expires_In;
     }

     public String getScopes() {
          return scopes;
     }

     public void setScopes(String scopes) {
          this.scopes = scopes;
     }

     public String getToken_type() {
          return token_type;
     }

     public void setToken_type(String token_type) {
          this.token_type = token_type;
     }
}
